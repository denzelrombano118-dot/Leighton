ANNIVERSARY WEBPAGE — FOR LEIGHTON

1. Put an audio file you have permission to use in this same folder.
2. Rename it to: music.mp3
3. Open index.html to preview it.
4. To publish it, upload the folder to a static web host such as GitHub Pages.

The page intentionally starts the music after Leighton taps "Open my letter",
because phones/browsers commonly block audio autoplay without a user interaction.
